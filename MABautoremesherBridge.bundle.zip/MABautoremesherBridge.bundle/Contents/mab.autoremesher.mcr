macroScript autoremesher category:"MYARTSBOX" tooltip:"Auto Remesher"
(
    filein "mab.autoremesher.ms" 
)